// ==========================================

// GREENLIFT: Smart Base Station Controller

// ==========================================

// Note: The main carousel DC motor is wired directly to the solar power 

// source with an independent manual switch, so it is not controlled here.



#define PUMP_RELAY_PIN 7   // Controls the 12V micro submersible pump

#define BUTTON_PIN 2       // Push-button to trigger the water pump

#define BUZZER_PIN 4       // Digital alarm buzzer



// Alarm Timer Settings (in milliseconds)

// Set to 10 seconds (10000 ms) for demonstration. Change to hours for real-world use.

unsigned long alarmInterval = 10000; 

unsigned long lastAlarmTime = 0;



void setup() {

  Serial.begin(9600);

  

  // Configure Pins

  pinMode(PUMP_RELAY_PIN, OUTPUT);

  pinMode(BUZZER_PIN, OUTPUT);

  pinMode(BUTTON_PIN, INPUT_PULLUP); // Uses internal pull-up resistor (LOW when pressed)

  

  // Ensure components are off at startup

  digitalWrite(PUMP_RELAY_PIN, LOW); 

  digitalWrite(BUZZER_PIN, LOW);

  

  Serial.println("GreenLift System Online!");

}



void loop() {

  unsigned long currentMillis = millis();

  

  // --- 1. INTERVAL ALARM LOGIC ---

  // Tracks time and sounds the buzzer to remind the user to spin and water the plants

  if (currentMillis - lastAlarmTime >= alarmInterval) {

    Serial.println("Reminder: Time to spin the carousel and water the plants!");

    

    // Play a 3-beep alarm sequence

    for (int i = 0; i < 3; i++) {

      digitalWrite(BUZZER_PIN, HIGH);

      delay(200);

      digitalWrite(BUZZER_PIN, LOW);

      delay(200);

    }

    

    lastAlarmTime = currentMillis; // Reset the interval timer

  }

  

  // --- 2. MANUAL RAINWATER PUMP LOGIC ---

  // Reads the push-button. If pressed, activates the relay to dispense rainwater.

  if (digitalRead(BUTTON_PIN) == LOW) {

    Serial.println("Dispensing harvested rainwater...");

    

    digitalWrite(PUMP_RELAY_PIN, HIGH); // Turn pump ON

    delay(2000);                        // Pump runs for exactly 2 seconds

    digitalWrite(PUMP_RELAY_PIN, LOW);  // Turn pump OFF

    

    Serial.println("Watering complete.");

    delay(1000); // 1-second debounce delay to prevent double-pumping

  }

}